import math
import logging
from functools import partial
from collections import OrderedDict
from copy import deepcopy
from typing import Callable, Dict, List, Optional, Tuple, Union

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


from timm.models.layers import to_2tuple

from lib.models.layers.patch_embed import PatchEmbed
from .FreqFusion import FreqFusion
from .final_fusion import CGAFusion
from .utils import combine_tokens, recover_tokens
from .vit import VisionTransformer
from ..layers.attn_blocks import CEBlock

_logger = logging.getLogger(__name__)


class VisionTransformerCE(VisionTransformer):
    """ Vision Transformer with candidate elimination (CE) module

    A PyTorch impl of : `An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale`
        - https://arxiv.org/abs/2010.11929

    Includes distillation token & head support for `DeiT: Data-efficient Image Transformers`
        - https://arxiv.org/abs/2012.12877
    """

    def __init__(self, img_size=224, patch_size=16, in_chans=3, num_classes=1000, embed_dim=64, depth=12,
                 num_heads=12, mlp_ratio=4., qkv_bias=True, representation_size=None, distilled=False,
                 drop_rate=0., attn_drop_rate=0., drop_path_rate=0., embed_layer=PatchEmbed, norm_layer=None,
                 act_layer=None, weight_init='',
                 ce_loc=None, ce_keep_ratio=None, **kwargs):
        """
        Args:
            img_size (int, tuple): input image size
            patch_size (int, tuple): patch size
            in_chans (int): number of input channels
            num_classes (int): number of classes for classification head
            embed_dim (int): embedding dimension
            depth (int): depth of transformer
            num_heads (int): number of attention heads
            mlp_ratio (int): ratio of mlp hidden dim to embedding dim
            qkv_bias (bool): enable bias for qkv if True
            representation_size (Optional[int]): enable and set representation layer (pre-logits) to this value if set
            distilled (bool): model includes a distillation token and head as in DeiT models
            drop_rate (float): dropout rate
            attn_drop_rate (float): attention dropout rate
            drop_path_rate (float): stochastic depth rate
            embed_layer (nn.Module): patch embedding layer
            norm_layer: (nn.Module): normalization layer
            weight_init: (str): weight init scheme
        """
        # super().__init__()
        super().__init__(**kwargs)
        if isinstance(img_size, tuple):
            self.img_size = img_size
        else:
            self.img_size = to_2tuple(img_size)
        self.patch_size = patch_size
        self.in_chans = in_chans

        self.num_classes = num_classes
        self.num_features = self.embed_dim = embed_dim  # num_features for consistency with other models
        self.num_tokens = 2 if distilled else 1
        norm_layer = norm_layer or partial(nn.LayerNorm, eps=1e-6)
        act_layer = act_layer or nn.GELU

        self.patch_embed = embed_layer(
            img_size=img_size, patch_size=patch_size, in_chans=in_chans, embed_dim=embed_dim)
        num_patches = self.patch_embed.num_patches

        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.dist_token = nn.Parameter(torch.zeros(1, 1, embed_dim)) if distilled else None
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + self.num_tokens, embed_dim))
        self.pos_drop = nn.Dropout(p=drop_rate)
        conv_dim = kwargs.get('conv_dim', 64)
        self.freqfusions = nn.ModuleList()
        for _ in range(3):
            self.freqfusions.append(
                FreqFusion(
                    lr_channels=conv_dim, hr_channels=conv_dim,
                    scale_factor=1,
                    lowpass_kernel=5,
                    highpass_kernel=3,
                    hamming_window=False,
                    comp_feat_upsample=True,
                    feature_resample=True,
                    feature_resample_group=4,
                    up_group=1,
                    encoder_kernel=3,
                    encoder_dilation=1,
                    compressed_channels=(conv_dim + conv_dim) // 8,
                    semi_conv=True,
                    upsample_mode='nearest',
                    align_corners=False,
                    hr_residual=True,
                    use_high_pass=True,
                    use_low_pass=True,
                    feature_resample_norm=False,
                )
            )
        self.freqfusions = self.freqfusions[::-1]


        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, depth)]  # stochastic depth decay rule
        blocks = []
        ce_index = 0
        self.ce_loc = ce_loc
        for i in range(depth):
            ce_keep_ratio_i = 1.0
            if ce_loc is not None and i in ce_loc:
                ce_keep_ratio_i = ce_keep_ratio[ce_index]
                ce_index += 1

            blocks.append(
                CEBlock(
                    dim=embed_dim, num_heads=num_heads, mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, drop=drop_rate,
                    attn_drop=attn_drop_rate, drop_path=dpr[i], norm_layer=norm_layer, act_layer=act_layer,
                    keep_ratio_search=ce_keep_ratio_i)
            )

        self.blocks = nn.Sequential(*blocks)
        self.norm = norm_layer(embed_dim)

        self.init_weights(weight_init)

    def forward_features(self, z, x, mask_z=None, mask_x=None,
                         ce_template_mask=None, ce_keep_rate=None,
                         return_last_attn=False
                         ):
        B, H, W = x.shape[0], x.shape[2], x.shape[3]
        # x = x.cpu().data.numpy()[0]
        # import matplotlib.pyplot as plt  #输出注意力分数图
        # plt.imshow(x.permute(1,2,0))
        # plt.show()



        x = self.patch_embed(x)
        z = self.patch_embed(z)
        ####################
        BZ, HZ, WZ = z.shape[0], z.shape[2], z.shape[3]
        BX, HX, WX = x.shape[0], x.shape[2], x.shape[3]
        x = x.reshape(BX,64,12,HX,WX).mean(axis=2)
        z = z.reshape(BZ, 64, 12,HZ, WZ).mean(axis=2)
        ######################
     #   _, z, x = self.freqfusions[-1](hr_feat=z, lr_feat=x, use_checkpoint=False)
        _, z, x = self.freqfusions[-1](hr_feat=x, lr_feat=z, use_checkpoint=False)
        x = x.flatten(2).transpose(1, 2)
        z = z.flatten(2).transpose(1, 2)

        x = x.repeat(1, 1, 12)
        z = z.repeat(1,3,1)
        z=z.permute(0,2,1)



        # x = x.cpu().detach().numpy()
        # z = z.cpu().detach().numpy()

     #   x = x.repeat(1,1,12)
        # x_resized = x[np.linspace(0, 31, 12, dtype=int)]
        # x = np.repeat(x_resized, 768 // 64, axis=2)
        #
        # z_resized = z[np.linspace(0, 31, 12, dtype=int), :, :]
        # z_selected = z_resized[:, :64, :]
        # z = np.repeat(z_selected, 768 // 64, axis=2)

        # x = torch.tensor(x, dtype=torch.float32)
        # z = torch.tensor(z, dtype=torch.float32)
        # x = x.to("cuda")
        # z = z.to("cuda")

        ####################
        ####
        # ct = ce_template_mask
        # indices = np.linspace(0, 31, 12, dtype=int)
        # ce_template_mask = ct[indices]

        ####
        # attention mask handling
        # B, H, W


        if mask_z is not None and mask_x is not None:

            mask_z = F.interpolate(mask_z[None].float(), scale_factor=1. / self.patch_size).to(torch.bool)[0]
            mask_z = mask_z.flatten(1).unsqueeze(-1)

            mask_x = F.interpolate(mask_x[None].float(), scale_factor=1. / self.patch_size).to(torch.bool)[0]
            mask_x = mask_x.flatten(1).unsqueeze(-1)

            mask_x = combine_tokens(mask_z, mask_x, mode=self.cat_mode)
            mask_x = mask_x.squeeze(-1)

        if self.add_cls_token:
            cls_tokens = self.cls_token.expand(B, -1, -1)
            cls_tokens = cls_tokens + self.cls_pos_embed


        zpos = self.pos_embed_z
        xpos = self.pos_embed_x

        ########################
  #      x=torch.tensor([x[0]*0.375,x[1],x[2]*12],dtype=torch.float32)
  #       x=torch.tensor([x[0]*0.375,x[1],x[2]*12],dtype=torch.float32)
  #       z=[z[0]*0.375,z[1]*0.25,z[2]*12]


        # x_resized = x[np.linspace(0,31,12,dtype=int)]
        # x_resized = x_resized.cpu().numpy()
        # x= np.repeat(x_resized,768//64,axis=2)
        # z_t={32:12,256:64,64:768}
        # z=[z_t[item] for item in z]
        # x_t={32:12,256:256,64:768}
        # x=[x_t[item] for item in x]

        # x = x.reshape(32, 256, 12, 64)
        # x = x.permute(0, 1, 3, 2).reshape(32, 256, 768)
        # x = x.view(12, 256, 768) mark
        # x=x.cpu().detach().numpy()
        # z = z.cpu().detach().numpy()
        # x_resized = x[np.linspace(0,31,12,dtype=int)]
        # x= np.repeat(x_resized,768//64,axis=2)
        #
        # z_resized = z[np.linspace(0,31,12,dtype=int),:,:]
        # z_selected = z_resized[:,:64,:]
        # z= np.repeat(z_selected,768//64,axis=2)
        #
        # x=torch.tensor(x,dtype=torch.float32)
        # z=torch.tensor(z,dtype=torch.float32)
        # x = x.to("cuda")
        # z = z.to("cuda")

        ####################mark



        z += self.pos_embed_z
        x += self.pos_embed_x

        if self.add_sep_seg:
            x += self.search_segment_pos_embed
            z += self.template_segment_pos_embed

        #######################

        ######################

        x = combine_tokens(z, x, mode=self.cat_mode)
    #    if self.add_cls_token:
      #      x = torch.cat([cls_tokens, x], dim=1)

        x = self.pos_drop(x)

        lens_z = self.pos_embed_z.shape[1]
        lens_x = self.pos_embed_x.shape[1]

        global_index_t = torch.linspace(0, lens_z - 1, lens_z).to(x.device)
        global_index_t = global_index_t.repeat(B, 1)

        global_index_s = torch.linspace(0, lens_x - 1, lens_x).to(x.device)
        global_index_s = global_index_s.repeat(B, 1)
        removed_indexes_s = []
        # for i, blk in enumerate(self.blocks):
        #     x, global_index_t, global_index_s, removed_index_s, attn = \
        #         blk(x, global_index_t, global_index_s, mask_x, ce_template_mask, ce_keep_rate)
        #
        #     if self.ce_loc is not None and i in self.ce_loc:
        #         removed_indexes_s.append(removed_index_s)

        # ! fix vis_in run
        vis_att_list = []

        for i, blk in enumerate(self.blocks):
            x, global_index_t, global_index_s, removed_index_s, attn = \
                blk(x, global_index_t, global_index_s, mask_x, ce_template_mask, ce_keep_rate)
            # temp_map = torch.zeros([lens_x], device=attn.device)

            # print(x.shape)
            # print(attn.shape)
            # print(global_index_s)
            # if global_index_s is not None:
            #     idx_list = [global_index_s_i.cpu().numpy() for global_index_s_i in global_index_s]
            #     print(attn)
            #     # attn = (attn - attn.min() ) / (attn.max() - attn.min())
            #     temp_map[:] = attn.min()
            #     for ti  in range(len(idx_list)):
            #         temp_map[idx_list[ti]] = attn[ti]

            attn = attn.reshape([int(lens_x ** 0.5), -1])
            vis_att_list += [attn, ]

            if self.ce_loc is not None and i in self.ce_loc:
                removed_indexes_s.append(removed_index_s)

        x = self.norm(x)
        lens_x_new = global_index_s.shape[1]
        lens_z_new = global_index_t.shape[1]

        z = x[:, :lens_z_new]
        x = x[:, lens_z_new:]

        if removed_indexes_s and removed_indexes_s[0] is not None:
            removed_indexes_cat = torch.cat(removed_indexes_s, dim=1)

            pruned_lens_x = lens_x - lens_x_new
            pad_x = torch.zeros([B, pruned_lens_x, x.shape[2]], device=x.device)
            x = torch.cat([x, pad_x], dim=1)
            index_all = torch.cat([global_index_s, removed_indexes_cat], dim=1)
            # recover original token order
            C = x.shape[-1]
            # x = x.gather(1, index_all.unsqueeze(-1).expand(B, -1, C).argsort(1))
            x = torch.zeros_like(x).scatter_(dim=1, index=index_all.unsqueeze(-1).expand(B, -1, C).to(torch.int64), src=x)

        x = recover_tokens(x, lens_z_new, lens_x, mode=self.cat_mode)

        # re-concatenate with the template, which may be further used by other modules
        x = torch.cat([z, x], dim=1)

        aux_dict = {
            # "attn": attn,vis_att_list
          #  "attn": vis_att_list,
            "attn": vis_att_list,
            "removed_indexes_s": removed_indexes_s,  # used for visualization
        }
        # print(aux_dict)
        return x, aux_dict

    def forward(self, z, x, ce_template_mask=None, ce_keep_rate=None,
                tnc_keep_rate=None,
                return_last_attn=False):

        x, aux_dict = self.forward_features(z, x, ce_template_mask=ce_template_mask, ce_keep_rate=ce_keep_rate,)

        return x, aux_dict


def _create_vision_transformer(pretrained=False, **kwargs):
    model = VisionTransformerCE(**kwargs)

    if pretrained:
        if 'npz' in pretrained:
            model.load_pretrained(pretrained, prefix='')
        else:
            checkpoint = torch.load(pretrained, map_location="cpu")
            missing_keys, unexpected_keys = model.load_state_dict(checkpoint["model"], strict=False)
            print('Load pretrained model from: ' + pretrained)

    return model


def vit_base_patch16_224_ce(pretrained=False, **kwargs):
    """ ViT-Base model (ViT-B/16) from original paper (https://arxiv.org/abs/2010.11929).
    """
    model_kwargs = dict(
        patch_size=16, embed_dim=768, depth=12, num_heads=12, **kwargs)
    model = _create_vision_transformer(pretrained=pretrained, **model_kwargs)
    return model


def vit_large_patch16_224_ce(pretrained=False, **kwargs):
    """ ViT-Large model (ViT-L/16) from original paper (https://arxiv.org/abs/2010.11929).
    """
    model_kwargs = dict(
        patch_size=16, embed_dim=1024, depth=24, num_heads=16, **kwargs)
    model = _create_vision_transformer(pretrained=pretrained, **model_kwargs)
    return model
