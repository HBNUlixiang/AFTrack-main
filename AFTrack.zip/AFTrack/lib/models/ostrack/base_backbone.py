from functools import partial

import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.ndimage import zoom
from timm.models.vision_transformer import resize_pos_embed
from timm.models.layers import DropPath, to_2tuple, trunc_normal_

from lib.models.layers.patch_embed import PatchEmbed
from lib.models.ostrack.FreqFusion import FreqFusion
from lib.models.ostrack.utils import combine_tokens, recover_tokens
from .final_fusion import CGAFusion

class BaseBackbone(nn.Module):
    def __init__(self,**kwargs):
        super().__init__()

        # for original ViT
        self.pos_embed = None
        self.img_size = [224, 224]
        self.patch_size = 16
        self.embed_dim = 384

        self.cat_mode = 'direct'

        self.pos_embed_z = None
        self.pos_embed_x = None

        self.template_segment_pos_embed = None
        self.search_segment_pos_embed = None

        self.return_inter = False
        self.return_stage = [2, 5, 8, 11]

        self.add_cls_token = False
        self.add_sep_seg = False

        ####################
        #######################

        super().__init__(**kwargs)
        conv_dim = kwargs.get('conv_dim', 64)
        self.mix = CGAFusion(dim=64, reduction=4)
    ################融合############################
        self.freqfusions = nn.ModuleList()
        for _ in range(3):
            self.freqfusions.append(
                FreqFusion(
                    lr_channels=conv_dim, hr_channels=conv_dim,
                    scale_factor=1,
                    lowpass_kernel=5,
                    highpass_kernel=3,
                    hamming_window=False,
                    comp_feat_upsample=True,
                    feature_resample=True,
                    feature_resample_group=4,
                    up_group=1,
                    encoder_kernel=3,
                    encoder_dilation=1,
                    compressed_channels=(conv_dim + conv_dim) // 8,
                    semi_conv=True,
                    upsample_mode='nearest',
                    align_corners=False,
                    hr_residual=True,
                    use_high_pass=True,
                    use_low_pass=True,
                    feature_resample_norm=False,
                )
            )
        self.freqfusions = self.freqfusions[::-1]
        #
        # ##############融合############
        #####################
    def finetune_track(self, cfg, patch_start_index=1):

        search_size = to_2tuple(cfg.DATA.SEARCH.SIZE)
        template_size = to_2tuple(cfg.DATA.TEMPLATE.SIZE)
        new_patch_size = cfg.MODEL.BACKBONE.STRIDE

        self.cat_mode = cfg.MODEL.BACKBONE.CAT_MODE
        self.return_inter = cfg.MODEL.RETURN_INTER
        self.return_stage = cfg.MODEL.RETURN_STAGES
        self.add_sep_seg = cfg.MODEL.BACKBONE.SEP_SEG

        # resize patch embedding
        if new_patch_size != self.patch_size:
            print('Inconsistent Patch Size With The Pretrained Weights, Interpolate The Weight!')
            old_patch_embed = {}
            for name, param in self.patch_embed.named_parameters():
                if 'weight' in name:
                    param = nn.functional.interpolate(param, size=(new_patch_size, new_patch_size),
                                                      mode='bicubic', align_corners=False)
                    param = nn.Parameter(param)
                old_patch_embed[name] = param
            self.patch_embed = PatchEmbed(img_size=self.img_size, patch_size=new_patch_size, in_chans=3,
                                          embed_dim=self.embed_dim)
            self.patch_embed.proj.bias = old_patch_embed['proj.bias']
            self.patch_embed.proj.weight = old_patch_embed['proj.weight']

        # for patch embedding
        patch_pos_embed = self.pos_embed[:, patch_start_index:, :]
        patch_pos_embed = patch_pos_embed.transpose(1, 2)
        B, E, Q = patch_pos_embed.shape
        P_H, P_W = self.img_size[0] // self.patch_size, self.img_size[1] // self.patch_size
        patch_pos_embed = patch_pos_embed.view(B, E, P_H, P_W)

        # for search region
        H, W = search_size
        new_P_H, new_P_W = H // new_patch_size, W // new_patch_size
        search_patch_pos_embed = nn.functional.interpolate(patch_pos_embed, size=(new_P_H, new_P_W), mode='bicubic',
                                                           align_corners=False)
        search_patch_pos_embed = search_patch_pos_embed.flatten(2).transpose(1, 2)

        # for template region
        H, W = template_size
        new_P_H, new_P_W = H // new_patch_size, W // new_patch_size
        template_patch_pos_embed = nn.functional.interpolate(patch_pos_embed, size=(new_P_H, new_P_W), mode='bicubic',
                                                             align_corners=False)
        template_patch_pos_embed = template_patch_pos_embed.flatten(2).transpose(1, 2)

        self.pos_embed_z = nn.Parameter(template_patch_pos_embed)
        self.pos_embed_x = nn.Parameter(search_patch_pos_embed)

        # for cls token (keep it but not used)
        if self.add_cls_token and patch_start_index > 0:
            cls_pos_embed = self.pos_embed[:, 0:1, :]
            self.cls_pos_embed = nn.Parameter(cls_pos_embed)

        # separate token and segment token
        if self.add_sep_seg:
            self.template_segment_pos_embed = nn.Parameter(torch.zeros(1, 1, self.embed_dim))
            self.template_segment_pos_embed = trunc_normal_(self.template_segment_pos_embed, std=.02)
            self.search_segment_pos_embed = nn.Parameter(torch.zeros(1, 1, self.embed_dim))
            self.search_segment_pos_embed = trunc_normal_(self.search_segment_pos_embed, std=.02)

        # self.cls_token = None
        # self.pos_embed = None

        if self.return_inter:
            for i_layer in self.return_stage:
                if i_layer != 11:
                    norm_layer = partial(nn.LayerNorm, eps=1e-6)
                    layer = norm_layer(self.embed_dim)
                    layer_name = f'norm{i_layer}'
                    self.add_module(layer_name, layer)

    def forward_features(self, z, x):
        #B, H, W = x.shape[0], x.shape[2], x.shape[3]
        z_init = z
        x_init = x
        #x = self.patch_embed2(x)
       # z = self.patch_embed2(z)
        x_init = self.patch_embed(x_init)
        z_init = self.patch_embed(z_init)
        # ####################融合#################
        x1 = x.reshape(-1,768,16,16)
        z1=z.reshape(-1,768,8,8 )
        BZ, HZ, WZ = z1.shape[0], z1.shape[2], z1.shape[3]
        BX, HX, WX = x1.shape[0], x1.shape[2], x1.shape[3]

        x = x.reshape(BX, 64, 12, HX, WX).mean(axis=2)
        z = z.reshape(BZ, 64, 12, HZ, WZ).mean(axis=2)

        #####   _, z, x = self.freqfusions[-1](hr_feat=z, lr_feat=x, use_checkpoint=False)
        _, z, x = self.freqfusions[-1](hr_feat=x, lr_feat=z, use_checkpoint=False)
        x = x.flatten(2).transpose(1, 2)
        z = z.flatten(2).transpose(1, 2)

        x = x.repeat(1, 1, 12)
        z = z.repeat(1, 3, 1)

        z = z.permute(0, 2, 1)
        prompt=z
        z=z_init
        x=x_init
    #    prompt = prompt.reshape(36,8,8,768)
     #   prompt=prompt.permute(0,3,1,2)


####################融合#################
#############mix###############
        # x1=x
        # z1=z
        # z1 = z1.cpu().detach().numpy()
        # z1=zoom(z1,(1,4,1),order=1)
        # z1 = torch.tensor(z1, dtype=torch.float32)
        # z1 = z1.to("cuda")
        # xz = self.mix(x1, z1)





#############mix###############
        # if self.add_cls_token:
        #     cls_tokens = self.cls_token.expand(B, -1, -1)
        #     cls_tokens = cls_tokens + self.cls_pos_embed
        # print(self.pos_embed_z.shape)
        # print(z.shape)
        z += self.pos_embed_z
        x += self.pos_embed_x

        #################384要把这个注释弄掉##########
        B,H,W=z.shape[0], z.shape[1], z.shape[2]
        prompt=prompt.reshape(B ,-1,W)
        #################384要把这个注释弄掉##########

        # for i, blk in enumerate(self.blocks2):
        #     prompt = blk(prompt)



#########################fru+mix############
        z = combine_tokens(z, prompt, mode=self.cat_mode)
################！！！！！！！！！！！！！！！！！！！！！！！！！！！！        #
        # if self.add_sep_seg:
        #     x += self.search_segment_pos_embed
        #     z += self.template_segment_pos_embed

        x = combine_tokens(z, x, mode=self.cat_mode)
        # if self.add_cls_token:
        #     x = torch.cat([cls_tokens, x], dim=1)

        x = self.pos_drop(x)
#############################ATTN
        for i, blk in enumerate(self.blocks):
            x=blk(x)
            #x,attn = blk(x)
            attn=x


        lens_z = self.pos_embed_z.shape[1]
        lens_x = self.pos_embed_x.shape[1]
        x = recover_tokens(x, lens_z, lens_x, mode=self.cat_mode)

        aux_dict = {"attn": attn}

        return self.norm(x), aux_dict

    def forward(self, z, x, **kwargs):
        """
        Joint feature extraction and relation modeling for the basic ViT backbone.
        Args:
            z (torch.Tensor): template feature, [B, C, H_z, W_z]
            x (torch.Tensor): search region feature, [B, C, H_x, W_x]

        Returns:
            x (torch.Tensor): merged template and search region feature, [B, L_z+L_x, C]
            attn : None
        """
        x, aux_dict = self.forward_features(z, x,)

        return x, aux_dict
